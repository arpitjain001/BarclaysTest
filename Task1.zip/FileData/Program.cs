﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;


namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            string firstArg = args[0];
            string secondArg = args[1];

            if (firstArg == "-v")
            {
                FileDetails fileDetails = new FileDetails();
                string response = fileDetails.Version(secondArg);
                Console.WriteLine(response);
            }
        }
    }
}
