﻿using System;
using FileData;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NUnit.Framework;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace FileDataTests
{
    [TestClass]
    public class ProgramTest
    {
        private Mock<IFileDetailsWrapper> mockFileDetailsWrapper;

        [SetUp]
        public void TestSetup()
        {
            mockFileDetailsWrapper = new Mock<IFileDetailsWrapper>();
        }

        [TearDown]
        public void TestTearDown()
        {
            mockFileDetailsWrapper = null;
        }

        [TestCase(0)]
        [TestCase(1)]
        public void TestArgsException_ShowFileDetails(int count)
        {
            Assert.ThrowsException<ArgumentException>(()=> Program.ShowFileDetails(new string[count], mockFileDetailsWrapper.Object));
        }

        [TestCase("", "C:\\")]
        [TestCase("-v", "")]
        [TestCase("-s", "")]
        public void TestArgsEmptyException_ShowFileDetails(string arg1, string arg2)
        {
            var args = new string[2] { arg1, arg2};
            Assert.ThrowsException<ArgumentNullException>(() => Program.ShowFileDetails(args, mockFileDetailsWrapper.Object));
        }

        [TestCase("-v", "C:\\")]
        public void TestMethod_ShowFileDetailsReturnVersion(string arg1, string arg2)
        {
            //Arrange
            var args = new string[2] { arg1, arg2 };
            mockFileDetailsWrapper.Setup(x => x.Version(arg2)).Returns("1.0.0");

            //Act
            Program.ShowFileDetails(args, mockFileDetailsWrapper.Object);

            //Assert
            mockFileDetailsWrapper.Verify(x => x.Version(arg2));
        }

        [TestCase("-s", "C:\\")]
        public void TestMethod_ShowFileDetailsReturnSize(string arg1, string arg2)
        {
            //Arrange
            var args = new string[2] { arg1, arg2 };
            mockFileDetailsWrapper.Setup(x => x.Size(arg2)).Returns(2);

            //Act
            Program.ShowFileDetails(args, mockFileDetailsWrapper.Object);

            //Assert
            mockFileDetailsWrapper.Verify(x => x.Size(arg2));
        }
    }
}
