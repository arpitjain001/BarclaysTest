﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FileData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace FileData.Tests
{
    [TestClass]
    public class FileDetailsClientTests
    {
        private FileDetailsClient targetClass;
        private Mock<IFileDetailsWrapper> mockFileDetailsWrapper;

        [SetUp]
        public void TestSetup()
        {
            mockFileDetailsWrapper = new Mock<IFileDetailsWrapper>();
            targetClass = new FileDetailsClient(mockFileDetailsWrapper.Object);
        }

        [TearDown]
        public void TestTearDown()
        {
            mockFileDetailsWrapper = null;
            targetClass = null;
        }

        [TestCase("C:\\Desktop", "1.2.0")]
        [TestCase("C:\\Desktop\\Test.txt", "2.2.1")]
        public void VersionTest(string filePath, string expectedOutput)
        {
            //Arrange
            mockFileDetailsWrapper.Setup(x => x.Version(filePath)).Returns(expectedOutput);

            // Act
            var actualOutput = targetClass.Version(filePath);
            
            // Assert
            Assert.AreEqual(expectedOutput, actualOutput);
        }

        [TestCase("C:\\Desktop\\Test.txt", 6)]
        [TestCase("C:\\Desktop", 2)]
        public void SizeTest(string filePath, int expectedOutput)
        {
            //Arrange
            mockFileDetailsWrapper.Setup(x => x.Size(filePath)).Returns(expectedOutput);

            // Act
            var actualOutput = targetClass.Size(filePath);

            // Assert
            Assert.AreEqual(expectedOutput, actualOutput);
        }
    }
}