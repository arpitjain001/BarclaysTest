﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using ThirdPartyTools;


namespace FileData
{
    public static class Program
    {
        //public static void Main(string[] args)
        //{
        //    string firstArg = args[0];
        //    string secondArg = args[1];

        //    if (firstArg == "-v")
        //    {
        //        FileDetails fileDetails = new FileDetails();
        //        string response = fileDetails.Version(secondArg);
        //        Console.WriteLine(response);
        //    }
        //}

        public static void Main(string[] args)
        {
            ShowFileDetails(args, new FileDetailsWrapper());
        }

        public static void ShowFileDetails(string[] args, IFileDetailsWrapper fileDetailsWrapper)
        {
            if (args.Length < 2)
                throw new ArgumentException("Requires two parameter of type string.");

            string firstArg = args[0];
            if (string.IsNullOrEmpty(firstArg))
                throw new ArgumentNullException("First argument Version/Size is empty.");

            string filePath = args[1];
            if (string.IsNullOrEmpty(filePath))
                throw new ArgumentNullException("Second argument FilePath is empty.");


            FileDetailsClient fileDetails = new FileDetailsClient(fileDetailsWrapper);
            if (firstArg == "-v")
            {
                string response = fileDetails.Version(filePath);
                Console.WriteLine(response);
            }
            else if (firstArg == "-s")
            {
                int response = fileDetails.Size(filePath);
                Console.WriteLine(response);
            }
        }
    }
}
