﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileData
{
    public class FileDetailsWrapper : IFileDetailsWrapper
    {
        private readonly FileDetails fileDetails = new FileDetails();

        public string Version(string filePath)
        {
            return fileDetails.Version(filePath);
        }

        public int Size(string filePath)
        {
            return fileDetails.Size(filePath);
        }
    }
}
